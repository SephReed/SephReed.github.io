

MazeDecoder = {};

MazeDecoder.skinAndConvertToInts = function(bracketedNumberString) {
	return bracketedNumberString.substr(1, bracketedNumberString.length-2)
	.split(',')
	.map(function(num){  return parseInt(num); });
}




MazeDecoder.oneUseValues = ["START", "END"]

MazeDecoder.class = {};
MazeDecoder.class.Maze = function(loadable) {
	var THIS = this;
	var tmp = loadable.split('-');
	var dimensions = MazeDecoder.skinAndConvertToInts(tmp[0]);
	var blockValues = MazeDecoder.skinAndConvertToInts(tmp[1]);

	THIS.raster = [];
	THIS.height = dimensions[0];
	THIS.width = dimensions[1];
	for(var row = 0; row < THIS.height; row++) {
		THIS.raster[row] = [];
		for(var col = 0; col < THIS.width; col++) {
			var blockNum = (row*THIS.width + col);
			var blockValue;
			if (blockNum < blockValues.length)
				blockValue = blockValues[blockNum]
			else {
				console.error("Values given for blocks do not meet predefined dimensions.  Defaulting to empty block.");
				blockValue = 0;
			}

			var block = THIS.raster[row][col] = new MazeDecoder.class.Block(blockValue, row, col);


			//error check that only one of all single use values (START and END) type blocks exist
			//also record each for later use.
			MazeDecoder.oneUseValues.forEach(function(value){
				if(block.has(Block[value])) {
					var attributeName = value.toLowerCase()+"Block"
					if(THIS[attributeName] == undefined)
						THIS[attributeName] = block;

					else console.error("Multiple "+value+" blocks found.  Maze out of spec (for now)");
				}
			});		
		}
	}
}


var BLOCK_PX_SIZE = 24;
var textOffsetX = (BLOCK_PX_SIZE/2)-4;
var textOffsetY = (BLOCK_PX_SIZE/2)+4;

MazeDecoder.class.Maze.prototype.getCanvas = function() {
	if(this.canvas == undefined) {

		var canvas = this.canvas = document.createElement("canvas");
		canvas.width = this.width * BLOCK_PX_SIZE;
		canvas.height = this.height * BLOCK_PX_SIZE;

		for(var row = 0; row < this.height; row++) {
			for(var col = 0; col < this.width; col++) {
				this.raster[row][col].drawSelf(canvas);
			}	
		}
	}

	return this.canvas;
};


MazeDecoder.class.Maze.prototype.analyzePaths = function() {
	var THIS = this;
	THIS.exploreFromNode(THIS.startBlock);
	var routeGraph = THIS.findRoutes(THIS.startBlock, THIS.endBlock);
	routeGraph.paths.forEach(function(path) {
		drawPath(path, THIS.canvas, "red");
	})

}


var ROUTE_ID_ITERATOR = -1;
MazeDecoder.class.Maze.prototype.findRoutes = function(start, end) {
	var ID;

	var routeGraph = {};
	routeGraph.nodes = [];
	routeGraph.paths = [];
	routeGraph.tentativePaths = [];
	routeGraph.ID = ROUTE_ID_ITERATOR++;

	this.hasUsefulPath(start, end, routeGraph, []);

	return routeGraph;
}


MazeDecoder.class.Maze.prototype.hasUsefulPath = function(checkMe, end, routeGraph, trace) {
	var THIS = this;

	var nodeIsUseful;

	if(checkMe == end)
		nodeIsUseful = true;

	else if(checkMe.isDeadEnd)
		nodeIsUseful = false;

	else {
		checkMe.paths.forEach(function(path){
			if(trace) {
				var loopback = trace.find(function(node) {
					return path.ends.indexOf(node) != -1;
				});

				if(loopback){
					if(trace[trace.length-1] == loopback)
						return;

					// else {
					// 	loopback.onRouteSet(routeGraph.ID, function(loopbackUseful){
					// 		path.routes[routeGraph.ID].isUseful = loopbackUseful;

					// 		if(loopbackUseful)
					// 			routeGraph.paths.push(path);
					// 	})
					// 	return;
					// }
				}
			}


			// if(path.ends.indexOf(trace[0]) != -1)
			// 	return;


			

			
	
			path.routes = path.routes || {};
	
			if(path.routes[routeGraph.ID] == undefined) {
				var route = path.routes[routeGraph.ID] = {};
				var nextNode = path.ends.filter(function(anEnd){
					return anEnd != checkMe;
				})[0];
	
				var nextTrace = trace.slice();
				nextTrace.push(checkMe);
	
				route.isUseful = nextNode ? THIS.hasUsefulPath(nextNode, end, routeGraph, nextTrace) : false;
				// route.isUseful = nextNode ? THIS.hasUsefulPath(nextNode, end, routeGraph, [checkMe]) : false;
				nodeIsUseful = nodeIsUseful || route.isUseful !== false;
	
				if(route.isUseful)
					routeGraph.paths.push(path);
			}
			else {
				// console.log("loop found", path)
				// drawPath(path, THIS.canvas, "blue")
				nodeIsUseful = path.routes[routeGraph.ID].isUseful !== false || nodeIsUseful;
			}
		});
	}

	if(nodeIsUseful)
		routeGraph.nodes.push(checkMe);

	checkMe.setRoute(routeGraph.ID, nodeIsUseful);
	return nodeIsUseful;
}



MazeDecoder.class.Maze.prototype.exploreFromNode = function(node) {
	var THIS = this;
	node.getExits().forEach(function(dirEnum) {
		if(node.paths[dirEnum] == undefined) { 
			var path = THIS.getPathInDirection(node, dirEnum);
			node.paths[dirEnum] = path
			drawPath(path, THIS.canvas);
			var nextNode = path.ends[1];
			THIS.exploreFromNode(nextNode);
		}
	});




	// if(exits.length > 1 || block.has(Block.START) || block.has(Block.END)) {
	// 	block.siblings = [];
	// }
	// else if(exits.length == 1 ){
	// 	this.exploreFromNode(this.getBlockInDirection(block, exits[0]))
	// }
	// else if(exits.length <= 0 ){
	// }

}


function drawPath(path, canvas, color) {
	var painter = canvas.getContext("2d");
	painter.beginPath();
	painter.strokeStyle =  color || '#FAFAFA';

	var offset = BLOCK_PX_SIZE/2;

	var start = path.ends[0];
	var startX = (start.col*BLOCK_PX_SIZE) + offset;
	var startY = (start.row*BLOCK_PX_SIZE) + offset;
	
	var end = path.ends[1];
	var endX = (end.col*BLOCK_PX_SIZE) + offset;
	var endY = (end.row*BLOCK_PX_SIZE) + offset;

	
	painter.moveTo(startX, startY);
	painter.lineTo(endX, endY);

	painter.stroke();
}




MazeDecoder.class.Maze.prototype.getBlockInDirection = function(fromBlock, dirEnum) {
	if(Block.directions.indexOf(dirEnum) == -1)
		console.error("Must use a direction type Block enum")

	else {
		var targetRow = fromBlock.row;
		var targetCol = fromBlock.col;

		switch (dirEnum) {
			case Block.UP:
				targetRow--; break;
			case Block.RIGHT:
				targetCol++; break;
			case Block.DOWN:
				targetRow++; break;
			case Block.LEFT:
				targetCol--; break;
		}

		if(targetRow < 0 || targetRow >= this.height
		|| targetCol[1] < 0 || targetCol >= this.width)
			console.error("Block has path leading out of maze")

		else return this.raster[targetRow][targetCol];
	}
};


MazeDecoder.class.Maze.prototype.getPathInDirection = function(fromBlock, dirEnum) {
	if(fromBlock.paths[dirEnum] != undefined)
		return fromBlock.paths[dirEnum];

	var lastDir = dirEnum, 
		ptr = fromBlock;
	
	var path = new MazeDecoder.class.Path(fromBlock);
	fromBlock.paths[dirEnum] = path;

	while(ptr) {
		ptr = this.getBlockInDirection(ptr, lastDir);
		exits = ptr.getExitsExcept(Block.reverse(lastDir));

		if(exits.length != 1 || ptr.has(Block.START) || ptr.has(Block.END)) {
			path.ends.push(ptr);
			ptr.paths[Block.reverse(lastDir)] = path;
			if(exits.length == 0)
				ptr.isDeadEnd = true;
			ptr = undefined;
		}
		else {
			path.steps.push(ptr);
			if(ptr.has(Block.MINE))
				path.mines++;

			lastDir = exits[0];
		}
	}

	return path;
}







MazeDecoder.class.Path = function(start) {
	this.ends = []
	this.ends.push(start);
	this.steps = [];
	this.mines = 0;
}




// MazeDecoder.class.Path = function(start) {
// 	this.ends = []
// 	this.ends.push(start);
// 	this.steps = [];
// 	this.mines = 0;
// }


// MazeDecoder.class.Path.prototype.onValue = function(addMe) {
// 	this
// }




// MazeDecoder.class.Graph = function(startBlock, endBlock) {
// 	this.nodes = [];
// 	this.addBlock(startBlock);
// 	this.addBlock(endBlock);
// }


// MazeDecoder.class.Graph.prototype.addBlock = function(addMe) {
// 	this
// }


// MazeDecoder.class.BlockNode = function(startBlock, endBlock) {
// 	this.nodes = [];
// 	this.addBlock(startBlock);
// 	this.addBlock(endBlock);
// }














MazeDecoder.enum = {};
var Block = MazeDecoder.enum.Block = {};
Block.UP = 1;
Block.RIGHT = 2;
Block.DOWN = 4;
Block.LEFT = 8;
Block.START = 16;
Block.END = 32;
Block.MINE = 64;
Block.directions = [Block.UP, Block.RIGHT, Block.DOWN, Block.LEFT];
Block.reverse = function(dirEnum) {
	switch (dirEnum) {
		case Block.UP:
			return Block.DOWN;

		case Block.RIGHT:
			return Block.LEFT;

		case Block.DOWN:
			return Block.UP;

		case Block.LEFT:
			return Block.RIGHT;
	}
}



MazeDecoder.class.Block = function(value, row, col) {
	this.value = value;
	this.row = row;
	this.col = col;
	this.paths = [];
	this.routes = [];
	this.routeListeners = [];
}

MazeDecoder.class.Block.prototype.has = function(blockEnum) {
	return (this.value & blockEnum) != 0;
};


MazeDecoder.class.Block.prototype.getExits = function() {
	var THIS = this;
	return Block.directions.filter(function(dirEnum) {
		return THIS.has(dirEnum);
	});
};



MazeDecoder.class.Block.prototype.getExitsExcept = function(dontInclude) {
	if(typeof dontInclude == "number")
		dontInclude = [dontInclude]

	return this.getExits().filter(function(dirEnum) {
		return dontInclude.indexOf(dirEnum) == -1;
	});
}





MazeDecoder.class.Block.prototype.setRoute = function(ID, value) {
	this.routes[ID] = value;

	var listeners = this.routeListeners[ID];
	if(listeners)
		listeners.forEach(function(fn) {
			fn(value);
		});
}

MazeDecoder.class.Block.prototype.onRouteSet = function(ID, fn) {
	if(this.routes[ID] !== undefined)
		fn(this.routes[ID]);
	 

	else {
		this.routeListeners[ID] = this.routeListeners[ID] || [];
		this.routeListeners[ID].push(fn);
	}
}




MazeDecoder.class.Block.prototype.drawSelf = function(canvas) {
	var x = this.col*BLOCK_PX_SIZE;
	var y = this.row*BLOCK_PX_SIZE;

	var painter = canvas.getContext('2d');
	painter.beginPath();
	painter.strokeStyle = '#0B8';
	painter.moveTo(x, y);

	if(this.has(Block.UP))
		painter.moveTo(x+BLOCK_PX_SIZE, y);
	else
		painter.lineTo(x+BLOCK_PX_SIZE, y);


	if(this.has(Block.RIGHT))
		painter.moveTo(x+BLOCK_PX_SIZE, y+BLOCK_PX_SIZE);
	else
		painter.lineTo(x+BLOCK_PX_SIZE, y+BLOCK_PX_SIZE);


	if(this.has(Block.DOWN))
		painter.moveTo(x, y+BLOCK_PX_SIZE);
	else
		painter.lineTo(x, y+BLOCK_PX_SIZE);


	if(this.has(Block.LEFT))
		painter.moveTo(x, y);
	else
		painter.lineTo(x, y);

	painter.stroke();


	var textX = x + textOffsetX;
	var textY = y + textOffsetY;

	painter.fillStyle = "#3ca106";
	if(this.has(Block.START))
		painter.fillText('S', textX, textY);

	if(this.has(Block.END))
		painter.fillText('E', textX, textY);

	painter.fillStyle = "#a10633";
	if(this.has(Block.MINE))
		painter.fillText('*', textX, textY);
}












